import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, recall_score, precision_score
from sklearn.metrics import f1_score, confusion_matrix
from sklearn.feature_selection import SelectKBest, f_classif
from imblearn.over_sampling import SMOTE
from collections import Counter
import seaborn as sns
import matplotlib.pyplot as plt
import os

class APTClassifier:
    def __init__(self, data_path, gram_type):
        """
        Initialize classifier with the preprocessed feature file
        gram_type: '1gram' or '2gram'
        """
        self.gram_type = gram_type
        self.df = pd.read_csv(data_path)
        self.X = self.df.iloc[:, :-1]  # All columns except last
        self.y = self.df.iloc[:, -1]   # Last column (labels)
        
        # Initialize splits as None
        self.X_train = None
        self.X_val = None
        self.X_test = None
        self.y_train = None
        self.y_val = None
        self.y_test = None
        self.scaler = None

    def analyze_class_distribution(self):
        """
        Analyze and print class distribution
        """
        class_dist = pd.Series(self.y).value_counts()
        print("\nClass Distribution:")
        for class_label, count in class_dist.items():
            print(f"Class {class_label}: {count} samples ({count/len(self.y)*100:.2f}%)")
        return class_dist

    def balance_with_smote(self):
        """
        Balance dataset using SMOTE reduced k_neighbors
        """
        print("\nApplying SMOTE balancing...")
        print("Original dataset shape:", Counter(self.y))
        
        smote = SMOTE(random_state=42, k_neighbors=4)
        X_resampled, y_resampled = smote.fit_resample(self.X, self.y)
        
        self.X = pd.DataFrame(X_resampled, columns=self.X.columns)
        self.y = pd.Series(y_resampled)
        
        print("Balanced dataset shape:", Counter(self.y))
        self.analyze_class_distribution()

    def clean_data(self):
        """
        Clean the dataset by removing duplicates and constant features
        """
        # Remove duplicates
        initial_size = len(self.X)
        self.X = self.X.drop_duplicates()
        self.y = self.y[self.X.index]
        print(f"Removed {initial_size - len(self.X)} duplicate instances")
        
        # Remove constant features
        constant_features = [col for col in self.X.columns 
                           if self.X[col].nunique() == 1]
        self.X = self.X.drop(constant_features, axis=1)
        
        print(f"Remaining features after cleaning: {self.X.shape[1]}")

    from sklearn.feature_selection import SelectKBest, f_classif

    def select_features(self, k=None):
        """
        Select top k features using ANOVA F-value
        """
        print(f"\nPerforming feature selection...")
        print(f"Original number of features: {self.X.shape[1]}")

        #calculate F-Scores for all features
        f_scores, p_values = f_classif(self.X, self.y)

        #create DataFrame of features and their F-scores
        feature_scores = pd.DataFrame({
            'Feature':self.X.columns,
            'F_Score': f_scores,
            'P_Value': p_values
        })

        # Sort by F-score in descending order
        feature_scores = feature_scores.sort_values('F_Score', ascending=False)
    
        # Print top 10 features and their scores
        print("\nTop 10 most important features:")
        print(feature_scores.head(10))
    
        if k is None:
            # Calculate number of significant features (p < 0.05)
            significant_features = feature_scores[feature_scores['P_Value'] < 0.05]
            k = len(significant_features)
            print(f"\nNumber of statistically significant features: {k}")
        
        # Select top k features
        selector = SelectKBest(score_func=f_classif, k=k)
        X_selected = selector.fit_transform(self.X, self.y)
        
        # Get selected feature names
        selected_features = self.X.columns[selector.get_support()].tolist()
        
        # Update X with selected features
        self.X = pd.DataFrame(X_selected, columns=[f'feature_{i}' for i in range(k)])
        
        print(f"Number of features after selection: {self.X.shape[1]}")

    def normalize_data(self):
        """
        Normalize features using StandardScaler
        """
        self.scaler = StandardScaler()
        self.X = pd.DataFrame(
            self.scaler.fit_transform(self.X),
            columns=self.X.columns
        )

    def split_data(self, test_size=0.2, val_size=0.2):
        """
        Split data into training, validation, and test sets
        """
        # First split: separate test set
        X_temp, self.X_test, y_temp, self.y_test = train_test_split(
            self.X, self.y, test_size=test_size, random_state=42, stratify=self.y
        )
        
        # Second split: separate validation set from remaining data
        val_ratio = val_size / (1 - test_size)
        self.X_train, self.X_val, self.y_train, self.y_val = train_test_split(
            X_temp, y_temp, test_size=val_ratio, random_state=42, stratify=y_temp
        )
        
        print(f"Training set size: {len(self.X_train)}")
        print(f"Validation set size: {len(self.X_val)}")
        print(f"Test set size: {len(self.X_test)}")

    def train_and_evaluate(self, classifier_name):
        """
        Train classifier and evaluate performance
        """
        # Initialize classifier
        if classifier_name == 'svm':
            clf = SVC(kernel='rbf', random_state=42)
        elif classifier_name == 'knn':
            clf = KNeighborsClassifier(n_neighbors=3)
        elif classifier_name == 'dt':
            clf = DecisionTreeClassifier(random_state=42)
        
        # Train classifier
        clf.fit(self.X_train, self.y_train)
        
        # Make predictions on validation set
        val_pred = clf.predict(self.X_val)
        
        # Calculate validation metrics
        val_metrics = {
            'accuracy': accuracy_score(self.y_val, val_pred),
            'precision': precision_score(self.y_val, val_pred, average='weighted'),
            'recall': recall_score(self.y_val, val_pred, average='weighted'),
            'f1': f1_score(self.y_val, val_pred, average='weighted'),
            'confusion_matrix': confusion_matrix(self.y_val, val_pred)
        }
        
        # Make predictions on test set
        test_pred = clf.predict(self.X_test)
        
        # Calculate test metrics
        test_metrics = {
            'accuracy': accuracy_score(self.y_test, test_pred),
            'precision': precision_score(self.y_test, test_pred, average='weighted'),
            'recall': recall_score(self.y_test, test_pred, average='weighted'),
            'f1': f1_score(self.y_test, test_pred, average='weighted'),
            'confusion_matrix': confusion_matrix(self.y_test, test_pred)
        }
        
        return val_metrics, test_metrics, clf

    def plot_confusion_matrix(self, cm, title, save_path):
        """
        Plot confusion matrix
        """
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title(title)
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.tight_layout()
        plt.savefig(save_path)
        plt.close()

    def save_results(self, classifier_name, val_metrics, test_metrics, save_dir):
        """
        Save classification results
        """
        # Create results directory if it doesn't exist
        os.makedirs(save_dir, exist_ok=True)
        
        # Save metrics to CSV
        results = {
            'Validation': {
                'Accuracy': val_metrics['accuracy'],
                'Precision': val_metrics['precision'],
                'Recall': val_metrics['recall'],
                'F1-score': val_metrics['f1']
            },
            'Test': {
                'Accuracy': test_metrics['accuracy'],
                'Precision': test_metrics['precision'],
                'Recall': test_metrics['recall'],
                'F1-score': test_metrics['f1']
            }
        }
        
        results_df = pd.DataFrame(results)
        results_df.to_csv(f'{save_dir}/{self.gram_type}_{classifier_name}_results.csv')
        
        # Save confusion matrices
        self.plot_confusion_matrix(
            val_metrics['confusion_matrix'],
            f'{self.gram_type} {classifier_name.upper()} Validation Confusion Matrix',
            f'{save_dir}/{self.gram_type}_{classifier_name}_val_confusion.png'
        )
        
        self.plot_confusion_matrix(
            test_metrics['confusion_matrix'],
            f'{self.gram_type} {classifier_name.upper()} Test Confusion Matrix',
            f'{save_dir}/{self.gram_type}_{classifier_name}_test_confusion.png'
        )

def main():
    # Set paths and parameters
    results_dir = 'classification_results'
    data_dir = 'processed_data'
    classifiers = ['svm', 'knn', 'dt']
    
    for gram_type in ['1gram', '2gram']:
        print(f"\nProcessing {gram_type} features:")
        
        # Initialize classifier
        classifier = APTClassifier(f'{data_dir}/{gram_type}_features.csv', gram_type)
        
        # Clean data
        print("Cleaning data...")
        classifier.clean_data()

        # Feature selection for 2-gram
        if gram_type == '2gram':
            classifier.select_features()  # det k based on stats features
        
        # Analyze class distribution before balancing
        print("\nClass distribution before balancing:")
        classifier.analyze_class_distribution()
        
        # Apply SMOTE balancing
        classifier.balance_with_smote()
        
        print("Normalizing data...")
        classifier.normalize_data()
        
        print("Splitting data...")
        classifier.split_data()
        
        # Train and evaluate all classifiers
        for clf_name in classifiers:
            print(f"\nTraining {clf_name.upper()}...")
            val_metrics, test_metrics, model = classifier.train_and_evaluate(clf_name)
            
            # Print validation metrics
            print("\nValidation Metrics:")
            print(f"Accuracy: {val_metrics['accuracy']:.4f}")
            print(f"Precision: {val_metrics['precision']:.4f}")
            print(f"Recall: {val_metrics['recall']:.4f}")
            print(f"F1-score: {val_metrics['f1']:.4f}")
            
            # Print test metrics
            print("\nTest Metrics:")
            print(f"Accuracy: {test_metrics['accuracy']:.4f}")
            print(f"Precision: {test_metrics['precision']:.4f}")
            print(f"Recall: {test_metrics['recall']:.4f}")
            print(f"F1-score: {test_metrics['f1']:.4f}")
            
            # Save results
            classifier.save_results(clf_name, val_metrics, test_metrics, results_dir)

if __name__ == "__main__":
    main()