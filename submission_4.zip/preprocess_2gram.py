# preprocess_2gram_script
import os
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
import pickle

def load_opcodes(data_path):
    """
    Load opcodes from files and their corresponding labels
    """
    opcodes = []
    labels = []
    
    for apt_group in os.listdir(data_path):
        group_path = os.path.join(data_path, apt_group)
        if os.path.isdir(group_path):
            for file_name in os.listdir(group_path):
                if file_name.endswith('.opcode'):
                    file_path = os.path.join(group_path, file_name)
                    with open(file_path, 'r') as f:
                        content = f.read().strip()
                        opcodes.append(content)
                        labels.append(apt_group)
    
    return opcodes, labels

def create_2gram_features(opcodes):
    """
    Create 2-gram features from opcodes
    """
    vectorizer = CountVectorizer(ngram_range=(2, 2))
    X = vectorizer.fit_transform(opcodes)
    
    # Save the vectorizer for later use
    with open('2gram_vectorizer.pkl', 'wb') as f:
        pickle.dump(vectorizer, f)
    
    return X.toarray(), vectorizer.get_feature_names_out()

def main():
    # Set paths
    data_path = 'Opcodes'
    output_path = 'processed_data'
    
    # Create output directory if it doesn't exist
    os.makedirs(output_path, exist_ok=True)
    
    # Load opcodes
    print("Loading opcodes...")
    opcodes, labels = load_opcodes(data_path)
    
    # Create 2-gram features
    print("Creating 2-gram features...")
    X, feature_names = create_2gram_features(opcodes)
    
    # Convert labels to numpy array
    y = np.array(labels)
    
    # Create DataFrame with features
    df = pd.DataFrame(X, columns=feature_names)
    df['label'] = y
    
    # Save processed data
    print("Saving processed data...")
    df.to_csv(os.path.join(output_path, '2gram_features.csv'), index=False)
    
    print("2-gram preprocessing complete!")

if __name__ == "__main__":
    main()